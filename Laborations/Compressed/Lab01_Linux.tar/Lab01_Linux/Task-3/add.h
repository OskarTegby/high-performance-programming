/* --- header file : add.h ---*/ 

int add(int, int);
