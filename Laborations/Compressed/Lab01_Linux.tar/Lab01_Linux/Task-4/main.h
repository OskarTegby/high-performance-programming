#include<stdio.h>
#include "readData.h"
#include "sort.h"
void printArray(int* , int);
