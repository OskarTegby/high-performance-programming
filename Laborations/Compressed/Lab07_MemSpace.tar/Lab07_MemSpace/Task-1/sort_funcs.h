typedef int intType;

void bubble_sort(intType* list, int N);
void merge_sort (intType* list, int N);
