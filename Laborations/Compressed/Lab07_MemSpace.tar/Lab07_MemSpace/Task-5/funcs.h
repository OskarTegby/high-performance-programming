void f();
int otherfunc(int number);
