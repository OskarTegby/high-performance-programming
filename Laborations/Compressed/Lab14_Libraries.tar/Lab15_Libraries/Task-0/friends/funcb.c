int Louise(int x) {
  return x*x*x;
}
