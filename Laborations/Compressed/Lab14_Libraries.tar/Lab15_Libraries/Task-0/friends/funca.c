int Thelma(int x) {
  return x*x;
}
