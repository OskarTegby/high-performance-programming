#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int printMatrix(int **matrix, int n);

int main(int argc, char const *argv[]) {
	int dim = atoi(argv[1]);
	int **matrix = malloc(dim * sizeof(&matrix));
	for (int i = 0; i < dim; i++) {
		matrix[i] = malloc(dim * sizeof(&matrix[i]));
	}

	matrix[0][0] = 1;
	for (int i = 1; i < dim; i++) {
		matrix[i][0] = 1;
		for (int j = 1; j < dim; j++) {
			matrix[i][j] = matrix[i-1][j] + matrix[i-1][j-1];
		}
	}
	printMatrix(matrix, dim);
	return 0;
}

int printMatrix(int** matrix, int n) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j <= i; j++) {
			printf("%d ", matrix[i][j]);
		}
		printf("\n");
	}
	return 0;
	printf("\n");
}