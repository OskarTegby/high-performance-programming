echo Hej hej
echo Nej tack